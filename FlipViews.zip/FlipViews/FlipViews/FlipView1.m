//
//  FlipView1.m
//  FlipViews
//
//  Created by Benny on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FlipView1.h"


@implementation FlipView1

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor whiteColor];
        CGRect f = CGRectMake(40, 80, 240, 240);
        imageFlipView1 = [[UIImageView alloc] initWithFrame: f];
        [imageFlipView1 setImage:[UIImage imageNamed: @"Smiley_Face.png"]];
        imageFlipView1.opaque = YES;
        [self addSubview: imageFlipView1];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
	UIFont *f = [UIFont systemFontOfSize: 32];
	[@"FlipView1" drawAtPoint: CGPointZero withFont: f];
}
*/

- (void)dealloc
{
    [super dealloc];
}

@end
