//
//  FlipViewsAppDelegate.h
//  FlipViews
//
//  Created by Benny on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FlipView;

@interface FlipViewsAppDelegate : NSObject <UIApplicationDelegate> {
    FlipView *flipView;
    UIWindow *_window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
