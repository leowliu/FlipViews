//
//  FlipView0.h
//  FlipViews
//
//  Created by Benny on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FlipView0 : UIView {
    UIImageView *imageFlipView0;
}

@end
