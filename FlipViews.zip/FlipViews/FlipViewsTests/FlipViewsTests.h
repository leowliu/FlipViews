//
//  FlipViewsTests.h
//  FlipViewsTests
//
//  Created by Benny on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface FlipViewsTests : SenTestCase {
@private
    
}

@end
